<?php
return array (
  'Defaults' => 'Alapértelmezett',
  'Event Types' => 'Esemény típus',
  'Other Calendars' => 'Más naptárak',
  'Snippet' => 'Oldalmenü',
);
