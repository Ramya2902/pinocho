<?php
return array (
  'Calendar' => 'Naptár',
  'Receive Calendar related Notifications.' => 'Naptár értesítések fogadása.',
);
