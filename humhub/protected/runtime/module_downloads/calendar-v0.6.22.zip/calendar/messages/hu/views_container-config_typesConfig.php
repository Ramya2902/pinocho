<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Új</strong> eseménytípus létrehozása',
  '<strong>Edit</strong> calendar' => '<strong>Naptár</strong> szerkesztése',
  '<strong>Edit</strong> event type' => '<strong>Eseménytípus</strong> szerkesztése',
);
