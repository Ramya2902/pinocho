<?php
return array (
  'Allows the user to create new calendar entries' => 'Engedélyezze a felhasználónak, hogy létrehozhasson új naptár bejegyzéseket',
  'Allows the user to edit/delete existing calendar entries' => 'Engedélyezze a felhasználünak, hogy szerkezthessen/törölhessen naptár bejegyzéseket',
  'Create entry' => 'Bejegyzés létrehozása',
  'Manage entries' => 'Bejegyzések kezelése',
);
