<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Esemény</strong> szűrése',
  '<strong>Select</strong> calendars' => '<strong>Válassz</strong> naptár(aka)t',
  'Followed spaces' => 'Követett témakörök',
  'Followed users' => 'Követett felhasználók',
  'I\'m attending' => 'Részt veszek',
  'My events' => 'Eseményeim',
  'My profile' => 'Profilom',
  'My spaces' => 'Témaköreim',
);
