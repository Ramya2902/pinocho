<?php

return [
    'Attend' => '',
    'Decline' => '',
    'Maybe' => '',
    'Participant information:' => '',
    'Read full description...' => '',
    'Read full participation info...' => '',
];
