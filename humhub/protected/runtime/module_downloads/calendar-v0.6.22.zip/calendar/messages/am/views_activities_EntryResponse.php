<?php

return [
    '%displayName% attends to %contentTitle%.' => '',
    '%displayName% maybe attends to %contentTitle%.' => '',
    '%displayName% not attends to %contentTitle%.' => '',
];
