<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% participe à %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% participe peut-être à %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% ne participe pas à %contentTitle%.',
);
