<?php
return array (
  'Defaults' => 'Standardinställning',
  'Event Types' => 'Aktivitetstyper',
  'Other Calendars' => 'Andra kalendrar',
  'Snippet' => 'Snippet',
);
