<?php
return array (
  'Attend' => 'Acceptera',
  'Decline' => 'Avböj',
  'Maybe' => 'Kanske',
  'Participant information:' => 'Deltagarinformation:',
  'Read full description...' => 'Läs hela beskrivningen...',
  'Read full participation info...' => 'Läs hela deltagarinformationen...',
);
