<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Skapa</strong> ny aktivitetstyp',
  '<strong>Edit</strong> calendar' => '<strong>Ändra</strong> kalender',
  '<strong>Edit</strong> event type' => '<strong>Ändra</strong> aktivitetstyp',
);
