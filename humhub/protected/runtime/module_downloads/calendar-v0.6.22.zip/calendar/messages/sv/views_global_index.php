<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrera</strong> aktiviteter',
  '<strong>Select</strong> calendars' => '<strong>Välj</strong> kalender',
  'Followed spaces' => 'Följda nätverk',
  'Followed users' => 'Följda användare',
  'I\'m attending' => 'Jag kommer',
  'My events' => 'Mina aktiviteter',
  'My profile' => 'Min profil',
  'My spaces' => 'Mina nätverk',
);
