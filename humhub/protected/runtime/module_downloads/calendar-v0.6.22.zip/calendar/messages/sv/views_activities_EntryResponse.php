<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% kommer till %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% kanske kommer till %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% kommer inte till %contentTitle%.',
);
