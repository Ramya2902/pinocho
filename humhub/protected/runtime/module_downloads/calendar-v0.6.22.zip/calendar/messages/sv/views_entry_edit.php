<?php
return array (
  '<strong>Create</strong> event' => '<strong>Skapa</strong> aktivitet',
  '<strong>Edit</strong> event' => '<strong>Ändra</strong> aktivitet',
  'Basic' => 'Grund',
  'Everybody can participate' => 'Alla kan delta',
  'Files' => 'Filer',
  'No participants' => 'Inga deltagare',
  'Participation' => 'Deltagande',
  'Select event type...' => 'Välj aktivitetstyp',
  'Title' => 'Rubrik',
);
