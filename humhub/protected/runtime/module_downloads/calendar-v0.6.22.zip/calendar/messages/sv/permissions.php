<?php
return array (
  'Allows the user to create new calendar entries' => 'Tillåter användaren att skapa nya kalenderinlägg',
  'Allows the user to edit/delete existing calendar entries' => 'Tillåter användaren att ändra/radera kalenderinlägg',
  'Create entry' => 'Skapa inlägg',
  'Manage entries' => 'Hantera inlägg',
);
