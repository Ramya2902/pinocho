<?php
return array (
  'Attend' => 'Participar',
  'Decline' => 'Recusar',
  'Maybe' => 'Talvez',
  'Participant information:' => 'Informação do participante:',
  'Read full description...' => 'Leia a descrição completa...',
  'Read full participation info...' => 'Leia a informação de participação completa...',
);
