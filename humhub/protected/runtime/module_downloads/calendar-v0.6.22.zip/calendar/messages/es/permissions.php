<?php
return array (
  'Allows the user to create new calendar entries' => 'Permitir que el usuario cree nuevas entradas en el calendario',
  'Allows the user to edit/delete existing calendar entries' => 'Permitir que el usuario edite o borre entradas del calendario existentes',
  'Create entry' => 'Crear entrada',
  'Manage entries' => 'Administrar entradas',
);
