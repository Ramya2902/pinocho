<?php
return array (
  ':count attending' => ':count asistirán',
  ':count declined' => ':count no asistirán',
  ':count maybe' => ':count tal vez',
  'Participants:' => 'Participantes: ',
);
