<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% chce wziąć udział w %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% może chce wziąć udział w %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nie chce wziąć udziału w %contentTitle%.',
);
