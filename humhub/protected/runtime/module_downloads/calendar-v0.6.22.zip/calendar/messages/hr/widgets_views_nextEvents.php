<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Nadolazeći</strong> događaji',
  'Open Calendar' => 'Otvori kalendar',
);
