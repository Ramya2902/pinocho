<?php
return array (
  ':count attending' => ':count piedalās',
  ':count declined' => ':count noraidīja',
  ':count maybe' => ':count varbūt',
  'Participants:' => 'Dalībnieki:',
);
