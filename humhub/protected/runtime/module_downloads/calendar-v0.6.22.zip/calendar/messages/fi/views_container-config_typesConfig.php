<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Luo</strong> uusi tapahtuma tyyppi',
  '<strong>Edit</strong> calendar' => '<strong>Muokkaa</strong> kalenteria',
  '<strong>Edit</strong> event type' => '<strong>Muokkaa</strong> tapahtuma tyyppiä',
);
