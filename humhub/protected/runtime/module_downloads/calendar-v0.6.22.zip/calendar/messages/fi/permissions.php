<?php
return array (
  'Allows the user to create new calendar entries' => 'Anna käyttäjien luoda uusia kalenterimerkintöjä',
  'Allows the user to edit/delete existing calendar entries' => 'Anna käyttäjien muokata / poistaa nykyisiä kalenterimerkintöjä',
  'Create entry' => 'Luo merkintä',
  'Manage entries' => 'Hallinoi merkintöjä',
);
