<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Tulevat</strong> tapahtumat',
  'Open Calendar' => 'Avaa Kalenteri',
);
