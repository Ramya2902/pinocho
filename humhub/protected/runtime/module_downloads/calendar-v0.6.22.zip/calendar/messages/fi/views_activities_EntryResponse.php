<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% osallistuu %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% osallistuu ehkä %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% ei osallistu %contentTitle%.',
);
