<?php

return [
    '<strong>Filter</strong> events' => '<strong>Suodata</strong> tapahtumia',
    '<strong>Select</strong> calendars' => '<strong>Valitse</strong> kalenteri',
    'Followed spaces' => 'Seuratut sivut',
    'Followed users' => 'Seuratut käyttäjät',
    'I\'m attending' => 'Minä osallistun',
    'My events' => 'Minun tapahtumat',
    'My profile' => 'Minun tapahtumat',
    'My spaces' => 'Minun sivut',
];
