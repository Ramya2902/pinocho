<?php
return array (
  'Calendar' => 'Kalenteri',
  'Receive Calendar related Notifications.' => 'Vastaanota kalenteriin liittyvät ilmoitukset.',
);
