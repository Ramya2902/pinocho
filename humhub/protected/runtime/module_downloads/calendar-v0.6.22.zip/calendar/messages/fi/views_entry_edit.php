<?php
return array (
  '<strong>Create</strong> event' => '<strong>Luo</strong> tapahtuma',
  '<strong>Edit</strong> event' => '<strong>Muokkaa</strong> tapahtumaa',
  'Basic' => 'Tavallinen',
  'Everybody can participate' => 'Kaikki voivat osallistua',
  'Files' => 'Tiedostot',
  'No participants' => 'Ei osallistujia',
  'Participation' => 'osallistujat',
  'Select event type...' => 'Valitse tapahtumatyyppi...',
  'Title' => 'Otsikko',
);
