<?php
return array (
  'Defaults' => 'Predefinite',
  'Event Types' => 'Tipi di evento',
  'Other Calendars' => 'Altri calendari',
  'Snippet' => 'Snippet',
);
