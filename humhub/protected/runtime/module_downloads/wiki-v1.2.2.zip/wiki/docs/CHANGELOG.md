Changelog
=========

1.2.2  (23 August, 2018)
------------------------
- Fix #82 Edit of category points to page edit

1.2.1  (23 August, 2018)
------------------------
- Fix: Overview link broken, when home page is set
- Chg: Swap like and comment link order (Felli)


1.2.0  (07 August, 2018)
------------------------
- Enh: Added categories
- Chg: Added page social controls (like, comments) into own widget
- Fix: "Pages without category" issue (olekrisek)


1.1.10
---------------------
- Enh: Added Page count configuration

