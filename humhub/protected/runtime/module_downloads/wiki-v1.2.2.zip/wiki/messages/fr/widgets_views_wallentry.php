<?php
return array (
  'Open wiki page...' => 'Ouvrir la page Wiki...',
);
