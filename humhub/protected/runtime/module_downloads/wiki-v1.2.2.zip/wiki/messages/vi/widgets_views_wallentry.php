<?php
return array (
  'Open wiki page...' => 'Mở trang Kiến thức...',
);
