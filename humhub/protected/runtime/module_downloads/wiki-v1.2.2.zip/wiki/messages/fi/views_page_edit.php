<?php

return [
    '<strong>Create</strong> new page' => '<strong>Luo</strong> uusi sivu',
    '<strong>Edit</strong> page' => '<strong>Muokkaa</strong> sivua',
    'Enter a wiki page name or url (e.g. http://example.com)' => 'Syötä sivun nimi tai url (esim. http://esimerkki.fi)',
    'New page title' => 'Uusi sivun nimi',
    'Save' => 'Tallenna',
];
