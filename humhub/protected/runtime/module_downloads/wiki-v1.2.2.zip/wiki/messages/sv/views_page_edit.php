<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Skapa</strong> ny sida',
  '<strong>Edit</strong> page' => '<strong>Ändra</strong> sida',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Lägg in wiki sidnamn eller url (e.g. http://example.com)',
  'New page title' => 'Ny sidrubrik',
  'Save' => 'Spara',
);
