Changelog
=========

1.0.1
-----------------------
- Fix: Message preview encoding issue

1.0.0
-----------------------
- Enh: Live updates
- Enh: Ajaxify conversation view
- Enh: Added conversation user list to mail overview
- Chng: Major refactoring

0.9.14  (July 2, 2018)
-----------------------
- Fix: PHP 7.2 compatibility issues


0.9.13  (Nune 13, 2018)
----------------------
- Enh: Added option to hide main navigation "Message" entry


0.9.9  (May 16, 2018)
----------------------
- Enh: Added global `StartConversation` permission


0.9.8 04.10.2017
----------------------
- Fix: #132 , #129 Added Conversation and Message Notification Categories