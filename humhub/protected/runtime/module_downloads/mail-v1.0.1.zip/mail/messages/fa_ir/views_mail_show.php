<?php

return [
    'Delete discussion' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>تایید</strong> حذف مکالمه',
    '<strong>Confirm</strong> leaving conversation' => '<strong>تایید</strong>  ترک مکالمه',
    '<strong>Confirm</strong> message deletion' => '<strong>تایید</strong>  حذف پیغام',
    'Add user' => 'اضافه کردن کاربر',
    'Cancel' => 'انصراف',
    'Delete' => 'حذف',
    'Do you really want to delete this conversation?' => 'آیا واقعا می‌خواهید این مکالمه را حذف کنید؟',
    'Do you really want to delete this message?' => 'آیا واقعا می‌خواهید این پیغام را حذف کنید؟',
    'Do you really want to leave this conversation?' => 'آیا واقعا می‌خواهید این مکالمه را ترک کنید؟',
    'Leave' => 'ترک',
    'Leave discussion' => 'ترک گفت‌وگو',
    'Send' => 'ارسال',
    'There are no messages yet.' => 'هنوز هیچ پیغامی وجود ندارد.',
];
