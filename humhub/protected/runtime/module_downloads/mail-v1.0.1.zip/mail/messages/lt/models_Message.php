<?php
return array (
  'New message from {senderName}' => 'Nauja žinutė nuo {senderName}',
  'and {counter} other users' => 'ir {counter} kitų vartotojų',
);
