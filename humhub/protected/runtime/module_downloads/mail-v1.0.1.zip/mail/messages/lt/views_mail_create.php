<?php

return [
    'Add recipients' => '',
    'New message' => 'Nauja Žinutė',
    'Send' => 'Išsiųsti',
];
