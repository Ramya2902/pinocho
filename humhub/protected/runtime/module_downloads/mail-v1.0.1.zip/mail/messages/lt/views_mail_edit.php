<?php

return [
    'Edit message entry' => 'Redaguoti žinutės tekstą',
];
