<?php

return [
    'Add recipients' => 'Aggiungi destinatari',
    'New message' => 'Nuovo messaggio',
    'Send' => 'Invia',
];
