<?php

return [
    'Add recipients' => 'Přidat příjemce',
    'New message' => 'Nová zpráva',
    'Send' => 'Poslat',
];
