<?php

return [
    'Conversations' => 'Conversacions',
    'New' => 'Nuevo',
    'There are no messages yet.' => 'Encara no i hai mensaches',
];
