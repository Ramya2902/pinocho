<?php

return [
    'Add recipients' => '',
    'New message' => 'Nuevo mensache',
    'Send' => 'Ninviar',
];
