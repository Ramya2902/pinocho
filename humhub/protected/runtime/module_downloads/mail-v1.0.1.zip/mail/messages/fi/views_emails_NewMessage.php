<?php
return array (
  '<strong>New</strong> message' => '<strong>Uusi</strong> viesti',
  'Reply now' => 'Vastaa nyt',
  'sent you a new message:' => 'lähetti sinulle uuden viestin:',
);
