<?php

return [
    'Edit message entry' => 'Muokkaa viestiä',
];
