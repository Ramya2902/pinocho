<?php
return array (
  'Recipient' => 'Vastaanottaja',
  'User {name} is already participating!' => 'Käyttäjä {name} osalistuu jo tähän!',
  'You are not allowed to send user {name} is already!' => 'Sinä et voi lähettää {name} :le viestejä',
  'You cannot send a email to yourself!' => 'Et voi lähettää viestiä itsellesi!',
);
