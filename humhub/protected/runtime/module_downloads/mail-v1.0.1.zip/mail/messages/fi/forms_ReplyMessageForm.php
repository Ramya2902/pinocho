<?php
return array (
  'Message' => 'Viesti',
);
