<?php

return [
    'Add more participants to your conversation...' => 'より多くの参加者を会話に加えてください...',
];
