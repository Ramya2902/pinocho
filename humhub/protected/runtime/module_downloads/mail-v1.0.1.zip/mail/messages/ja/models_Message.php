<?php
return array (
  'New message from {senderName}' => '{senderName}さんから新しいメッセージ',
  'and {counter} other users' => '他{counter}人のユーザー',
);
