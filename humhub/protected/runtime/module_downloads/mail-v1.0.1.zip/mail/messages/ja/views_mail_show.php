<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '',
    '<strong>Confirm</strong> leaving conversation' => '',
    '<strong>Confirm</strong> message deletion' => '',
    'Delete discussion' => '',
    'Do you really want to delete this conversation?' => '',
    'Do you really want to delete this message?' => '',
    'Do you really want to leave this conversation?' => '',
    'Leave' => '',
    'Add user' => 'ユーザーを追加',
    'Cancel' => 'キャンセル',
    'Delete' => '削除',
    'Leave discussion' => 'ディスカッションを残す',
    'Send' => '送信',
    'There are no messages yet.' => 'まだ何もメッセージはありません。',
];
