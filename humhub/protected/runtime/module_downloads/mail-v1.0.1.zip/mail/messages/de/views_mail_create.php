<?php

return [
    'Add recipients' => 'Empfänger hinzufügen',
    'New message' => 'Neue Nachricht',
    'Send' => 'Senden',
];
