<?php
return array (
  '<strong>New</strong> message' => '<strong>Nouveau</strong> message',
  'Reply now' => 'Répondre maintenant',
  'sent you a new message:' => 'vous a envoyé un nouveau message :',
);
