<?php
return array (
  'New message from {senderName}' => '',
  'and {counter} other users' => '',
);
