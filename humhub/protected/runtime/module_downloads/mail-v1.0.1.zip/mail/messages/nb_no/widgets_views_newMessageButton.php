<?php
return array (
  'New message' => 'Ny melding',
  'Send message' => 'Send melding',
);
