<?php
return array (
  'New message from {senderName}' => 'Ny melding fra {senderName}',
  'and {counter} other users' => 'og {counter} andre brukere',
);
