<?php
return array (
  'Recipient' => 'Ontvanger',
  'User {name} is already participating!' => 'Gebruiker {name} doet al mee!',
  'You are not allowed to send user {name} is already!' => 'U mag {naam} niet uitnodigen. Deze naam is al in gebruik!',
  'You cannot send a email to yourself!' => 'U  kunt geen e-mail naar uzelf sturen!',
);
