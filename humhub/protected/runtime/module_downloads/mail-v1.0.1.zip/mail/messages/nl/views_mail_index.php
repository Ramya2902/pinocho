<?php

return [
    'Conversations' => 'Gesprekken',
    'New' => 'Nieuw',
    'There are no messages yet.' => 'Er zijn nog geen berichten.',
];
