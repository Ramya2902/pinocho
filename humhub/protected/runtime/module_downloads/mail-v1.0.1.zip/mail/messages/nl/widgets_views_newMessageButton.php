<?php
return array (
  'New message' => 'Nieuw bericht',
  'Send message' => 'Verstuur bericht',
);
