<?php

return [
    'Conversations' => 'Beszélgetések',
    'New' => 'Új',
    'There are no messages yet.' => 'Még nincsenek üzenetek.',
];
