<?php

return [
    'Add more participants to your conversation...' => 'Adj hozzá további címzetteket...',
];
