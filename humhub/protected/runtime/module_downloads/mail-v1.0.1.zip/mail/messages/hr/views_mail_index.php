<?php

return [
    'Conversations' => 'Razgovori',
    'New' => 'Novo',
    'There are no messages yet.' => 'Još nema poruka.',
];
