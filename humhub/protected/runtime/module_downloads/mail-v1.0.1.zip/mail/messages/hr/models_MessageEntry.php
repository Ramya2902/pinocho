<?php
return array (
  'New message in discussion from %displayName%' => 'Nova poruka u raspravi od %displayName%',
);
