<?php

return [
    'Edit message entry' => 'تعديل محتوي الرسالة',
];
