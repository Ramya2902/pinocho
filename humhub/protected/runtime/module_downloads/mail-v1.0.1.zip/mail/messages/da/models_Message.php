<?php
return array (
  'New message from {senderName}' => 'Ny besked fra {senderName}',
  'and {counter} other users' => 'og {counter} andre brugere',
);
