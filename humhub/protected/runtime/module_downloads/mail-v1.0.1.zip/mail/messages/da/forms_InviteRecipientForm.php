<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Modtager',
    'You cannot send a email to yourself!' => 'Du kan ikke sende en besked til dig selv!',
];
