<?php

return [
    'There are no messages yet.' => '',
];
